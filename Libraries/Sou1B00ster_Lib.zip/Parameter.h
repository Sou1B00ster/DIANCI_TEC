#ifndef _PARAMETER_H_
#define _PARAMETER_H_
#include "headfile.h"
//#include "Parameter.h"

#define ADC_L 	 AD_value[0]
#define ADC_MID  AD_value[5]
#define ADC_R 	 AD_value[3]
#define ADC_LVER AD_value[1]
#define ADC_RVER AD_value[2]
#define ADC_LIL  AD_value[4]
#define ADC_LIR  AD_value[6]
#define ADC_NUM 7
#define SAMP_FRE 10

#define L_PWM  PWMA_CH1P_P10
#define R_PWM  PWMA_CH3P_P24
#define L_GPIO P1_3
#define R_GPIO P2_6

#define Pluse_left  CTIM0_P34//��34,35
#define Pluse_right CTIM3_P04//��04,53
#define dir_left P35
#define dir_right P53

#define PI 3.14159f//���妰
#define RAD_TO_ANGLE(rad) ((rad) * 180.0 / PI)//���廡��ת�Ƕȵĺ���

#define LCD_SWITCH P16
#define BEEN P52
#define key_enter     P17 //����
#define key_return    P51//����
#define key_write      P36//����
//#define key_up        P51//����
#define key_add       P37 //����
#define key_sub       P50//����


extern float AD_value[ADC_NUM];
extern float motorl_encoder_speed,motorr_encoder_speed;
extern float basicspeed;
extern float left_setspeed,right_setspeed;
extern float dif_kp,dif_kp_two;
extern float dif_kd,dif_kd_two;
float cha_a,cha_b,cha_c;
extern float motorl_end_value,motorr_end_value;
extern int chuxian_flag;
extern int cir_rec_1,cir_rec_2,cir_rec_3;
extern int circ_diuxian_flag;
extern int left_pre_flag,left_jin_flag,left_into_flag,left_chu_flag; 
extern int right_pre_flag,right_jin_flag,right_into_flag,right_chu_flag;
extern int block_Dir;
extern int timepi;
extern int flag_block_detected;
extern float Angle_block;
extern int flag_block_adjust;
extern int encoder_flag;
extern float motor_total_encoder;
extern float write_in_num[8];
extern float flash_read_num[8];//����Ϊdif_kp_two,dif_kd,cir_rec_1,cir_rec_2,cir_rec_3,goalvalue,block_Dir//���긳ֵ
extern int write_in_flag;//0Ϊδд�������Ĳ�����1Ϊд���

















#endif