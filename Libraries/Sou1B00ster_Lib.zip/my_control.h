#ifndef __MY_CONTROL_H
#define __MY_CONTROL_H
#include "headfile.h"
#include "Parameter.h"

/***********��������**********/
//extern float basicspeed;
//extern float left_setspeed,right_setspeed;
//extern float dif_kp,dif_kp_two;
//extern float dif_kd,dif_kd_two;
/***********��������**********/
void Dif_speed_control(void);
void been_err(void);

#endif