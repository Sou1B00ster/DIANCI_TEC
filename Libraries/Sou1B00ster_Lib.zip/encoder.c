#include "encoder.h"
#include "Control.h"
#include "sb.h"
float motor_total_encoder=0,motorl_total_encoder=0,motorr_total_encoder=0;
float motorl_encoder_raw,motorr_encoder_raw;
float motorl_encoder_speed,motorr_encoder_speed;
int16  encoder_flag=0;
int16  encoder_left_flag=0;
void encoder_init(void)
{
	 ctimer_count_init(Pluse_left);
	 ctimer_count_init(Pluse_right);
}
void Catch_encoder_value(void)
{  
	
	motorl_encoder_raw=ctimer_count_read(Pluse_left);
//	motorl_encoder_speed=motorl_encoder_speed*low_pass+motorl_encoder_raw*(1-low_pass);
	ctimer_count_clean(Pluse_left);//��ʱ�������
	
  motorr_encoder_raw=ctimer_count_read(Pluse_right);
//	motorr_encoder_speed=motorr_encoder_speed*low_pass+motorr_encoder_raw*(1-low_pass);
	ctimer_count_clean(Pluse_right);//��ʱ�������

	if(dir_left==0) 
	  motorl_encoder_speed = (-1)*motorl_encoder_raw;
	else
		motorl_encoder_speed = motorl_encoder_raw;
	if(dir_right==1)
	  motorr_encoder_speed = (-1)*motorr_encoder_raw;
	else
		motorr_encoder_speed = motorr_encoder_raw;
	
}
void Catch_encoder_road(void)
{
	
	if(encoder_left_flag==0)
	{
		motorl_total_encoder=0;
	}
	if(encoder_flag==0)
	{
	 motor_total_encoder=0;
	} 
	 if(encoder_flag)
	{
	 motor_total_encoder +=(motorl_encoder_speed+motorr_encoder_speed)/2;
	}
	 if(encoder_left_flag)
	 {
	 motorl_total_encoder += motorl_encoder_speed; 	 
	 }  
}
