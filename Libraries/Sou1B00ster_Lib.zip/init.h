#ifndef _INIT_H_
#define _INIT_H_
#include "headfile.h"
#include "Parameter.h"
#include "my_sb.h"

void adc_all_init(void);
void Motor_pwm_init(void);
void INIT_ALL(void);


#endif