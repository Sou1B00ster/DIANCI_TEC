#include "element.h"
#include "20602_CTRL.h"

//*******************Բ��*********************/
int cir_rec_1=60,cir_rec_2=40,cir_rec_3=63;
int circ_diuxian_flag=0;
int left_pre_flag=0,left_jin_flag=0,left_into_flag=0,left_chu_flag=0; 
int right_pre_flag=0,right_jin_flag=0,right_into_flag=0,right_chu_flag=0;
float Angle_circ=0;

void circ_recognition(void)
{
	if(ADC_L>cir_rec_1&&ADC_LIL>cir_rec_2&&ADC_LIR>cir_rec_3&&circ_diuxian_flag==0)
	{
		left_pre_flag=encoder_flag=1;
	}
	if(ADC_R>cir_rec_1&&ADC_LIR>cir_rec_2&&ADC_LIL>cir_rec_3&&circ_diuxian_flag==0)
	{
		right_pre_flag=encoder_flag=1;
	}

}
void circ_handler(void)
{  /***********�뻷׼��**********/
	 
if(left_pre_flag)
	{

		circ_diuxian_flag=1;
		if(motor_total_encoder>3400)
			{	
				cha_a=1; 
				cha_b=cha_c=10;
				encoder_flag=0;
				left_pre_flag=0;
				left_jin_flag=1;
			}
		else	
			{
				cha_a=1;
				cha_b=cha_c=0;
			}
	}
if(right_pre_flag)
  	{ 

		circ_diuxian_flag=1;
		if(motor_total_encoder>3400)
			{		
				cha_a=1; 
				cha_b=cha_c=10;
				encoder_flag=0;
				right_pre_flag=0;
				right_jin_flag=1;
			}
	    else	
			{
				cha_a=1;
				cha_b=cha_c=0;
			}
	}
	/************�뻷���***********/
if(left_jin_flag)
	{ 
		Angle_circ += icm20602_gyro_z*0.04 / 65.5;
	    if(Angle_circ>30)
			{			
				left_into_flag=1;
				left_jin_flag=0;
			}
    	else 
			{
				left_setspeed=50;
				right_setspeed=150;
			}
    }
if(right_jin_flag)
	{
		Angle_circ += icm20602_gyro_z*0.04 / 65.5;
	    if(Angle_circ<-30)
			{
				right_into_flag=1;
				right_jin_flag=0;
			}
    	else 
			{
				left_setspeed=150;
				right_setspeed=50;
			 }
	}
//	/*************����**************/
if(left_into_flag)
	{
		Angle_circ += icm20602_gyro_z*0.04 / 65.5;
		if(Angle_circ>320)
			{ 
				cha_a=1;
				cha_b=cha_c=0;
				dif_kp_two=1.2;
				left_chu_flag=encoder_flag=1;
				left_into_flag=0;
			}	 
	}
if(right_into_flag)
	{
		Angle_circ += icm20602_gyro_z*0.04 / 65.5;
		if(Angle_circ<-320)
			{ 
				cha_a=1;
				cha_b=cha_c=0;
				dif_kp_two=1.2;
				right_chu_flag=encoder_flag=1;
				right_into_flag=0;
			}	 
	}
//***********����׼��*************/
if(left_chu_flag)
	{		 
		if(motor_total_encoder>5000)
			{		 
				cha_a=1; 
				cha_b=cha_c=8;		
				dif_kp_two=2.24;				
			 	circ_diuxian_flag=0;
			    encoder_flag=0;		
			 	left_chu_flag=0;
				Angle_circ=0;			
			}	
	 }
if(right_chu_flag)
	{	
		if(motor_total_encoder>5000)
			{ 
				cha_a=1; 
				cha_b=cha_c=8;	 
				dif_kp_two=2.24;			
				circ_diuxian_flag=0;
				encoder_flag=0;		
				right_chu_flag=0;
				Angle_circ=0;	
			}	
	}
}






int chuxian_flag=0;
int block_Dir=0;
int timepi=0;
int flag_block_detected;
float Angle_block=0;
int flag_block_adjust=0;
int flag_block_back=0;
/*****************************************����**********************************/
void block_recognition(void)//ʶ��
{	
	if(dl1b_distance_mm<850&&circ_diuxian_flag==0&&timepi==0)//������д��
		{
			flag_block_detected=chuxian_flag=1; // ��⵽�ϰ���   			
		}	
}
///*****************************�����************************************************/
void block_handler_L(void)
{	
	if(flag_block_detected)
		{		
			timepi=1;//��ʾ��������
			left_setspeed=30;
			right_setspeed=170;
			Angle_block += icm20602_gyro_z*0.04 / 65.5;
	    }
		if(Angle_block>40)
			{
				flag_block_detected = 0;
				flag_block_back = 1;
			}
		if(flag_block_back)
			{
				Angle_block += icm20602_gyro_z*0.04 / 65.5;
				if(Angle_block >-25)
					{
						right_setspeed =40;
						left_setspeed = 160;
					}
				else
					{
						flag_block_adjust = 1;
					}
				if(flag_block_adjust)
					{
						left_setspeed= 60;
						right_setspeed = 140;
					}
			}
    if(Angle_block < 15 && Angle_block > -15 && flag_block_adjust)
		{
		  	chuxian_flag=0;
			flag_block_detected = 0;
			flag_block_back=0;
			flag_block_adjust = 0;
			Angle_block = 0;
		}
}
/*****************************�ұ���************************************************/
void block_handler_R(void)
{	
	if(flag_block_detected)
		{			
			timepi=1;
			left_setspeed=170;  
			right_setspeed=30;
			Angle_block += icm20602_gyro_z*0.04 / 65.5;
		}
    if(Angle_block<-40)
		{
			flag_block_detected = 0;
			flag_block_back = 1;
		}
	if(flag_block_back)
		{
			Angle_block += icm20602_gyro_z*0.04 / 65.5;
			if(Angle_block<25)
				{
					right_setspeed =160;
					left_setspeed = 40;
				}
			else
				{
					flag_block_adjust = 1;
				}
		if(flag_block_adjust)
			{
				left_setspeed= 140;
				right_setspeed = 60;
			}
		}
if(Angle_block < 15 && Angle_block > -15 && flag_block_adjust)
    {
//	    	left_setspeed=0;  
//	    	right_setspeed=0;
		chuxian_flag=0;
		flag_block_detected = 0;
		flag_block_back=0;
        flag_block_adjust = 0;
        Angle_block = 0;
    }
}

